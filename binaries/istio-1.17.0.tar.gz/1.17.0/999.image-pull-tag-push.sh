#--------------------------------------------------------------
# pull public image
#--------------------------------------------------------------
# operator
docker pull docker.io/istio/operator:1.17.0

# control plane
docker pull docker.io/istio/proxyv2:1.17.0
docker pull docker.io/istio/pilot:1.17.0

# add-ons
docker pull quay.io/kiali/kiali:v1.63
docker pull docker.io/prom/prometheus:v2.34.0
docker pull docker.io/grafana/grafana:9.0.1
docker pull docker.io/jaegertracing/all-in-one:1.35
docker pull docker.io/jimmidyson/configmap-reload:v0.5.0

# sample applications
docker pull docker.io/istio/examples-bookinfo-details-v1:1.17.0
docker pull docker.io/istio/examples-bookinfo-productpage-v1:1.17.0
docker pull docker.io/istio/examples-bookinfo-ratings-v1:1.17.0
docker pull docker.io/istio/examples-bookinfo-reviews-v1:1.17.0
docker pull docker.io/istio/examples-bookinfo-reviews-v2:1.17.0
docker pull docker.io/istio/examples-bookinfo-reviews-v3:1.17.0

#--------------------------------------------------------------
# tag to v2-zcr
#--------------------------------------------------------------
# operator
docker tag docker.io/istio/operator:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/operator:1.17.0

# control plane
docker tag docker.io/istio/proxyv2:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/proxyv2:1.17.0
docker tag docker.io/istio/pilot:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/pilot:1.17.0

# add-ons
docker tag quay.io/kiali/kiali:v1.63 v2-zcr.cloudzcp.io/cloudzcp-public/kiali/kiali:v1.63
docker tag docker.io/prom/prometheus:v2.34.0 v2-zcr.cloudzcp.io/cloudzcp-public/prom/prometheus:v2.34.0
docker tag docker.io/grafana/grafana:9.0.1 v2-zcr.cloudzcp.io/cloudzcp-public/grafana/grafana:9.0.1
docker tag docker.io/jaegertracing/all-in-one:1.35 v2-zcr.cloudzcp.io/cloudzcp-public/jaegertracing/all-in-one:1.35
docker tag docker.io/jimmidyson/configmap-reload:v0.5.0 v2-zcr.cloudzcp.io/cloudzcp-public/jimmidyson/configmap-reload:v0.5.0

# sample applications
docker tag docker.io/istio/examples-bookinfo-details-v1:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-details-v1:1.17.0
docker tag docker.io/istio/examples-bookinfo-productpage-v1:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-productpage-v1:1.17.0
docker tag docker.io/istio/examples-bookinfo-ratings-v1:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-ratings-v1:1.17.0
docker tag docker.io/istio/examples-bookinfo-reviews-v1:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-reviews-v1:1.17.0
docker tag docker.io/istio/examples-bookinfo-reviews-v2:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-reviews-v2:1.17.0
docker tag docker.io/istio/examples-bookinfo-reviews-v3:1.17.0 v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-reviews-v3:1.17.0

#--------------------------------------------------------------
# push to v2-zcr
#--------------------------------------------------------------
# operator
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/operator:1.17.0

# control plane
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/proxyv2:1.17.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/pilot:1.17.0

# add-ons
docker push v2-zcr.cloudzcp.io/cloudzcp-public/kiali/kiali:v1.63
docker push v2-zcr.cloudzcp.io/cloudzcp-public/prom/prometheus:v2.34.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/grafana/grafana:9.0.1
docker push v2-zcr.cloudzcp.io/cloudzcp-public/jaegertracing/all-in-one:1.35
docker push v2-zcr.cloudzcp.io/cloudzcp-public/jimmidyson/configmap-reload:v0.5.0

# sample applications
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-details-v1:1.17.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-productpage-v1:1.17.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-ratings-v1:1.17.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-reviews-v1:1.17.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-reviews-v2:1.17.0
docker push v2-zcr.cloudzcp.io/cloudzcp-public/istio/examples-bookinfo-reviews-v3:1.17.0
