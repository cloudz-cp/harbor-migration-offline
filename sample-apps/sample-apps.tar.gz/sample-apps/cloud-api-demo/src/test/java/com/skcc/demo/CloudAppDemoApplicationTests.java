package com.skcc.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudAppDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
