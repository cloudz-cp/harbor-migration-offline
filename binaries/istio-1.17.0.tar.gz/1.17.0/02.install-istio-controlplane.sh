#!/bin/bash
. ./env.properties

# replace variables
set -e

if [ "x${HUB_REGISTRY}" != "x" ]
then
    echo "HUB Registry is ${HUB_REGISTRY}"
    # sed 's/VAR_HUB_REGISTRY/'"${HUB_REGISTRY}"'/g' istio-default.yaml > istio-default-temp1.yaml
else
    echo "HUB Registry is empty!!!"
    exit
fi

if [ "x${TAG}" != "x" ]
then
    echo "Tag is ${TAG}"
    # sed 's/VAR_TAG/'"${TAG}"'/g' istio-default-temp1.yaml > istio-default-temp2.yaml
else
    echo "Tag is empty!!!"
    exit
fi

kubectl apply -f istio-default.yaml
