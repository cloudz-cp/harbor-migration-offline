istioctl verify-install
