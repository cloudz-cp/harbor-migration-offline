# delete sample apps
kubectl delete -f ./istio-1.17.0/samples/bookinfo/platform/kube/bookinfo.yaml -n default
kubectl delete -f ./istio-1.17.0/samples/bookinfo/networking/bookinfo-gateway.yaml -n default

# delete istio addons
kubectl delete -f ./istio-1.17.0/samples/addons -n istio-system

