kubectl label namespace default istio-injection=enabled --overwrite=true
kubectl apply -f ./istio-1.17.0/samples/bookinfo/platform/kube/bookinfo.yaml -n default
kubectl apply -f ./istio-1.17.0/samples/bookinfo/networking/bookinfo-gateway.yaml -n default

