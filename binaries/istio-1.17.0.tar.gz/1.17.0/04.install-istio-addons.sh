kubectl apply -f ./istio-1.17.0/samples/addons -n istio-system

kubectl rollout status deployment/kiali -n istio-system

