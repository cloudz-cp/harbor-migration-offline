package com.skcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudMovieApplication.class, args);
	}
}
