package com.skcc.demo.vo;

import lombok.Data;

@Data
public class UserVo {
	
	private Integer id;

	private String name;
}
