package com.skcc.authentication.vo;

public enum Authority {
	ADMIN, USER
}
