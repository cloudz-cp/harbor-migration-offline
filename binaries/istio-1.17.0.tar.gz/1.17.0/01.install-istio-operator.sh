#!/bin/bash
. ./env.properties

# replace variables
set -e

if [ "x${HUB_REGISTRY}" != "x" ]
then
    echo "HUB Registry is ${HUB_REGISTRY}"
else
    echo "HUB Registry is is empty!!!"
    exit
fi

if [ "x${TAG}" != "x" ]
then
    echo "Tag is ${TAG}"
else
    echo "Tag is empty!!!"
    exit
fi

istioctl operator init --hub ${HUB_REGISTRY} --tag ${TAG}
